import torch
from LLM_Scratch_Code import RawLLM, device, tokenizer

checkpoint = torch.load("saved_raw_llm/model.pt", map_location="cpu")

model = RawLLM(
    vocab_size=checkpoint["vocab_size"],
    context_length=checkpoint["context_length"],
)

model.load_state_dict(checkpoint["model_state_dict"])
model.eval()
model.to(device)

print("Model loaded.")

@torch.no_grad()
def generate(model, tokenizer, prompt, max_new_tokens=100):
    model.eval()

    tokens = tokenizer.encode(prompt)
    tokens = tokens[-model.context_length:]

    input_ids = torch.tensor(tokens, dtype=torch.long, device=device).unsqueeze(0)

    for _ in range(max_new_tokens):
        logits = model(input_ids)
        next_token_logits = logits[:, -1, :]
        next_token = torch.argmax(next_token_logits, dim=-1)

        input_ids = torch.cat([input_ids, next_token.unsqueeze(1)], dim=1)

        if input_ids.size(1) > model.context_length:
            input_ids = input_ids[:, -model.context_length:]

    output_tokens = input_ids.squeeze(0).tolist()
    return "".join(tokenizer.itos.get(t, "") for t in output_tokens)
prompt = (
    "Context: Plants are living things that grow from seeds.\n"
    "Question: What is a plant?\n"
    "Instruction: Explain simply.\n"
    "Answer:"
)

print(generate(model, tokenizer, prompt))
