import torch
import torch.nn as nn
import torch.nn.functional as F
import math

class CausalSelfAttention(nn.Module):
    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        assert d_model % n_heads == 0

        self.d_model = d_model
        self.n_heads = n_heads
        self.head_dim = d_model // n_heads

        self.qkv = nn.Linear(d_model, 3 * d_model)
        self.out_proj = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)

        # causal mask (registered as buffer, not a parameter)
        self.register_buffer(
            "mask",
            torch.tril(torch.ones(1, 1, 1024, 1024))
        )

    def forward(self, x):
        B, T, C = x.size()

        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=-1)

        q = q.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        k = k.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)
        v = v.view(B, T, self.n_heads, self.head_dim).transpose(1, 2)

        attn_scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn_scores = attn_scores.masked_fill(
            self.mask[:, :, :T, :T] == 0,
            float("-inf")
        )

        attn_probs = F.softmax(attn_scores, dim=-1)
        attn_probs = self.dropout(attn_probs)

        attn_output = attn_probs @ v
        attn_output = attn_output.transpose(1, 2).contiguous()
        attn_output = attn_output.view(B, T, C)

        return self.out_proj(attn_output)


class FeedForward(nn.Module):
    def __init__(self, d_model, hidden_dim, dropout=0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(d_model, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, d_model),
            nn.Dropout(dropout),
        )

    def forward(self, x):
        return self.net(x)


class TransformerBlock(nn.Module):
    def __init__(self, d_model, n_heads, ffn_dim, dropout=0.1):
        super().__init__()
        self.ln1 = nn.LayerNorm(d_model)
        self.attn = CausalSelfAttention(d_model, n_heads, dropout)
        self.ln2 = nn.LayerNorm(d_model)
        self.ffn = FeedForward(d_model, ffn_dim, dropout)

    def forward(self, x):
        x = x + self.attn(self.ln1(x))
        x = x + self.ffn(self.ln2(x))
        return x


class RawLLM(nn.Module):
    def __init__(
        self,
        vocab_size=32000,
        context_length=512,
        d_model=512,
        n_layers=12,
        n_heads=8,
        ffn_dim=2048,
        dropout=0.1,
    ):
        super().__init__()

        self.token_embedding = nn.Embedding(vocab_size, d_model)
        self.position_embedding = nn.Embedding(context_length, d_model)

        self.blocks = nn.ModuleList([
            TransformerBlock(d_model, n_heads, ffn_dim, dropout)
            for _ in range(n_layers)
        ])

        self.ln_f = nn.LayerNorm(d_model)
        self.lm_head = nn.Linear(d_model, vocab_size, bias=False)

        # weight tying
        self.lm_head.weight = self.token_embedding.weight

        self.context_length = context_length

        self.apply(self._init_weights)

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.Embedding):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)

    def forward(self, input_ids):
        B, T = input_ids.size()
        assert T <= self.context_length

        positions = torch.arange(0, T, device=input_ids.device).unsqueeze(0)

        x = self.token_embedding(input_ids) + self.position_embedding(positions)

        for block in self.blocks:
            x = block(x)

        x = self.ln_f(x)
        logits = self.lm_head(x)

        return logits


import json
import random
import torch
class QADataset:
    def __init__(self, json_path, tokenizer, context_length):
        with open(json_path, "r", encoding="utf-8") as f:
            self.data = json.load(f)

        self.tokenizer = tokenizer
        self.context_length = context_length

    def sample(self):
        item = random.choice(self.data)

        text = (
            f"Context: {item['context']}\n"
            f"Question: {item['question']}\n"
            f"Instruction: {item['instruction']}\n"
            f"Answer: {item['answer']}"
        )

        token_ids = self.tokenizer.encode(text)

        # truncate
        token_ids = token_ids[: self.context_length + 1]

        input_ids = token_ids[:-1]
        targets = token_ids[1:]

        # pad if needed
        pad_id = self.tokenizer.pad_id
        while len(input_ids) < self.context_length:
            input_ids.append(pad_id)
            targets.append(pad_id)

        return (
            torch.tensor(input_ids, dtype=torch.long),
            torch.tensor(targets, dtype=torch.long),
        )

class CharTokenizer:
    def __init__(self, texts):
        chars = sorted(list(set("".join(texts))))
        self.stoi = {ch: i + 1 for i, ch in enumerate(chars)}
        self.itos = {i: ch for ch, i in self.stoi.items()}
        self.pad_id = 0
        self.vocab_size = len(self.stoi) + 1

    def encode(self, text):
        return [self.stoi.get(ch, self.pad_id) for ch in text]


import torch
import torch.nn.functional as F
from torch.cuda.amp import autocast, GradScaler


"""
# ------------------ config ------------------

micro_batch_size = 1
max_grad_norm = 1.0
context_length = 128
grad_accum_steps = 16

device = "cuda"
lr = 3e-4
steps = 5000

vocab_size = 32000
context_length = 128  # start small; can increase later
# -------------------------------------------

model = RawLLM(
    vocab_size=vocab_size,
    context_length=context_length
).to(device)
model.train()

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=lr,
    betas=(0.9, 0.95),
    weight_decay=0.1
)

scaler = GradScaler()
optimizer.zero_grad(set_to_none=True)
with open("primary_qa_100.json", "r", encoding="utf-8") as f:
    raw_data = json.load(f)

all_texts = [
    f"{d['context']} {d['question']} {d['instruction']} {d['answer']}"
    for d in raw_data
]

tokenizer = CharTokenizer(all_texts)

# ------------------ training loop ------------------
for step in range(steps):

    # dummy batch placeholder (replace with real data loader)
    input_ids = torch.randint(
        0, vocab_size, (micro_batch_size, context_length), device=device
    )
    targets = input_ids.clone()

    with autocast(dtype=torch.float16):
        logits = model(input_ids)
        loss = F.cross_entropy(
            logits.view(-1, vocab_size),
            targets.view(-1),
        )
        loss = loss / grad_accum_steps

    scaler.scale(loss).backward()

    if (step + 1) % grad_accum_steps == 0:
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        scaler.step(optimizer)
        scaler.update()
        optimizer.zero_grad(set_to_none=True)

    if step % 100 == 0:
        print(f"step {step} | loss {(loss * grad_accum_steps).item():.4f}")
import os

save_dir = "saved_raw_llm"
os.makedirs(save_dir, exist_ok=True)

checkpoint = {
    "model_state_dict": model.state_dict(),
    "vocab_size": tokenizer.vocab_size,
    "context_length": context_length,
}

torch.save(checkpoint, os.path.join(save_dir, "model.pt"))
print("Model saved.")
"""
with open("primary_qa_100.json", "r", encoding="utf-8") as f:
    raw_data = json.load(f)

all_texts = [
    f"{d['context']} {d['question']} {d['instruction']} {d['answer']}"
    for d in raw_data
]

tokenizer = CharTokenizer(all_texts)

vocab_size = 32000
context_length = 128
device = "cuda"
checkpoint = torch.load("saved_raw_llm/model.pt", map_location="cuda")

model = RawLLM(
    vocab_size=vocab_size,
    context_length=context_length,
)

model.load_state_dict(checkpoint["model_state_dict"])
model.eval()
model.to(device)

print("Model loaded.")

@torch.no_grad()
def generate(model, tokenizer, prompt, max_new_tokens=30):
    model.eval()

    tokens = tokenizer.encode(prompt)
    tokens = tokens[-model.context_length:]

    input_ids = torch.tensor(tokens, dtype=torch.long, device=device).unsqueeze(0)

    for _ in range(max_new_tokens):
        logits = model(input_ids)
        next_token_logits = logits[:, -1, :]
        next_token = torch.argmax(next_token_logits, dim=-1)

        input_ids = torch.cat([input_ids, next_token.unsqueeze(1)], dim=1)

        if input_ids.size(1) > model.context_length:
            input_ids = input_ids[:, -model.context_length:]

    output_tokens = input_ids.squeeze(0).tolist()
    return "".join(tokenizer.itos.get(t, "") for t in output_tokens)
prompt = (
    "Context: Plants are living things that grow from seeds.\n"
    "Question: What is a plant?\n"
    "Instruction: Explain simply.\n"
    "Answer:"
)

print(generate(model, tokenizer, prompt))
