import json

questions_answers = [
    ("What is your name?", "My name is what people use to call me."),
    ("How old are you?", "My age tells how many years I have lived."),
    ("What is your favorite color?", "My favorite color is the color I like most."),
    ("How many letters are there in the English alphabet?", "There are 26 letters in the English alphabet."),
    ("What is the opposite of big?", "The opposite of big is small."),
    ("What is the opposite of happy?", "The opposite of happy is sad."),
    ("What do we call a place where books are kept?", "A place where books are kept is called a library."),
    ("What is a sentence?", "A sentence is a group of words that makes complete sense."),
    ("What is a noun?", "A noun is the name of a person, place, or thing."),
    ("What is a verb?", "A verb is a word that shows an action."),
    # … continue up to all 100 questions (pattern remains identical)
]

dataset = []

for idx, (q, a) in enumerate(questions_answers, start=1):
    context = f"This lesson explains basic ideas for young students. {a}"
    dataset.append({
        "id": idx,
        "context": context,
        "question": q,
        "instruction": "Explain simply.",
        "answer": a
    })

with open("primary_qa_dataset.json", "w") as f:
    json.dump(dataset, f, indent=2)

print("Dataset created with", len(dataset), "samples.")
